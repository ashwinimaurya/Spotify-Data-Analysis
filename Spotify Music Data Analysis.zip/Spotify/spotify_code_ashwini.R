library(stats)
# let "C:/Users/Ashwini/Desktop/Spotify" be the directory where the data is stored.
setwd("C:/Users/Ashwini/Desktop/Spotify");
# read the user_data_sample
user=as.data.frame(read.csv("user_data_sample.csv",header=TRUE));
# read the end_song_sample
data1=as.data.frame(read.csv("end_song_sample.txt",header=TRUE));
# combine the user_data with end_data
total=merge(data1,user,by="user_id")  
#read the file with name countries and continent
country_code=as.data.frame(read.csv("cd_code1.csv",header=TRUE));
#merge the total data with countries & continent data
total1=merge(country_code,total,by="country")  
# sort the data by user_id
total1=total1[order(total$user_id),]
# create the continent demographics in user data
user_new=merge(country_code,user,by="country")  
# sort the user data b user_id
user_new=user_new[order(user_new$user_id),];

###############  Data Diagnostics ###############################
# to see if there are invalid values for variable acct_age_weeks
length(which(user$acct_age_weeks<0))

############ TABLE 1 code  ######################
aggregate(user_id~gender+age_range,user_new,length)
############ TABLE 2 code  ######################
aggregate(user_id~gender+continent,user_new,length)

####################################################################
#################### Analysis by gender ############################
####################################################################

# in terms of count of tracks listened by users
# a) overall

############ TABLE 3 code  ######################

total_g=total1[,c(2,3,4,5,6,7,9,10)]; total_g=total_g[total_g$gender!="unknown",];
user_new=user_new[user_new$gender!="unknown",];
# number of tracks by gender  # ignoring the unknowns
a11=as.data.frame(table(total_g$user_id));colnames(a11)=c("user_id","no_of_tracks");
# next get the no. of tracks by each user and gender
user_tr=merge(user_new,a11);
n_g=aggregate(user_id~gender,user_tr,length);
avg_tr_g=aggregate(no_of_tracks~gender,user_tr,mean)[1:2,];
sd_tr_g=aggregate(no_of_tracks~gender,user_tr,sd)[1:2,];
z=(avg_tr_g$no_of_tracks[1]-avg_tr_g$no_of_tracks[2])/sqrt(sd_tr_g$no_of_tracks[1]^2/n_g[1,2]+sd_tr_g$no_of_tracks[2]^2/n_g[2,2])
n_g;
avg_tr_g;
sd_tr_g;
z;

# b) by age-group

############ TABLE 4 code  ######################

user_ag=user_tr[-c(which(user_tr$age_range=="")),];
n_ga=aggregate(no_of_tracks~gender+age_range,user_ag,length);
avg_tr_ga=aggregate(no_of_tracks~gender+age_range,user_ag,mean);
sd_tr_ga=aggregate(no_of_tracks~gender+age_range,user_ag,sd);
za=rep(0,7);
for(i in 1:7)
{
  st=(i-1)*2+1;en=st+1;
  za[i]=(avg_tr_ga$no_of_tracks[st]-avg_tr_ga$no_of_tracks[en])/sqrt((sd_tr_ga$no_of_tracks[st])^2/n_ga$no_of_tracks[st]+(sd_tr_ga$no_of_tracks[en])^2/n_ga$no_of_tracks[en])
}

n_ga;
avg_tr_ga;
sd_tr_ga;
za;

############# in terms of average time spent on tracks############

############ TABLE 5 code  ######################

a12=aggregate(ms_played~user_id,total_g,sum);
colnames(a12)=c("user_id","m_played");
# next get the no. of tracks by each user and gender
user_tr=merge(user_tr,a12,by="user_id");
avg_tr_g1=aggregate(m_played~gender,user_tr,mean);
sd_tr_g1=aggregate(m_played~gender,user_tr,sd);
z1=(avg_tr_g1$m_played[1]-avg_tr_g1$m_played[2])/sqrt(sd_tr_g1$m_played[2]^2/n_g[1,2]+sd_tr_g1$m_played[2]^2/n_g[2,2])

n_g;
avg_tr_g1[,2]/1000/60;
sd_tr_g1[,2]/1000/60;
z1;


############ TABLE 6 code  ######################

# b) by age-group
user_ga1=user_tr[-c(which(user_tr$age_range=="")),];
n_ga1=aggregate(user_id~gender+age_range,user_ga1,length);
avg_tr_ga1=aggregate(m_played~gender+age_range,user_ga1,mean);
sd_tr_ga1=aggregate(m_played~gender+age_range,user_ga1,sd);
za1=rep(0,7);
for(i in 1:7)
{
  st=(i-1)*2+1;en=st+1;
    za1[i]=(avg_tr_ga1$m_played[st]-avg_tr_ga1$m_played[en])/sqrt((sd_tr_ga1$m_played[st])^2/n_ga1[st,3]+(sd_tr_ga1$m_played[en])^2/n_ga1[en,3])
}

n_ga1;
avg_tr_ga1;
sd_tr_ga1;
za1;


################################################################################
############# next check for the user listeing age_range by demographics########
################################################################################


############ TABLE 7 code  ######################

totald=total1;
usercp=user_tr[user_tr$continent!="Proxy",]
nd=aggregate(user_id~gender+continent,usercp,length)
nd;

############ TABLE 8 code  ######################

# in terms of total time spent on tracks
tr_dg=aggregate(m_played~gender+continent,usercp,mean)
tr_dg;

############ TABLE 9 code  ######################

#next find the popularity of produc across the continents
ndpcg=aggregate(user_id~context+gender+product,total_g,length);
ndpcg;

############ TABLE 10 code  ######################

dat_pcg=aggregate(ms_played~user_id+context+gender+product,total_g,sum);
tr_pcg=aggregate(ms_played~context+gender+product,dat_pcg,mean);
tr_pcg[,4]/1000/60

################################################################################
######### next check for the user listeing by continent and product ############
################################################################################

############ TABLE 11 code  ######################

totalc=total1;
totalc=totalc[totalc$continent!="",];
totalcp=totalc[totalc$product!="",];
totalcpg=totalcp[totalcp$gender!="unknown",];
ndpag=aggregate(user_id~age_range+gender+product,total1,length);
ndpag;

############ TABLE 12 code  ######################

dat_pag=aggregate(ms_played~user_id+age_range+gender+product,total1,sum);
tr_pag=aggregate(ms_played~age_range+gender+product,dat_pag,mean);
tr_pag;

############ TABLE 13 code  ######################

ndpcng=aggregate(user_id~continent+gender+product,total1,length);
ndpcng[1:5,]

############ TABLE 14 code  ######################

dat_pcng=aggregate(ms_played~user_id+continent+gender+product,total1,sum);
tr_pcng=aggregate(ms_played~continent+gender+product,dat_pcng,mean);
tr_pcng[,4]/1000/60

